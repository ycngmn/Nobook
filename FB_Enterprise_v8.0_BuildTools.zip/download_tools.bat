@echo off
title Downloading FB Enterprise Tools
color 0B
echo.
echo  ================================================
echo    Auto Download — FB Enterprise Build Tools
echo  ================================================
echo.

if not exist "%~dp0tools" mkdir "%~dp0tools"

:: ── apktool.jar ──
echo [1/3] Downloading apktool v2.9.3...
if exist "%~dp0tools\apktool.jar" (
    echo   [SKIP] apktool.jar da ton tai
) else (
    powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -Uri 'https://github.com/iBotPeaches/Apktool/releases/download/v2.9.3/apktool_2.9.3.jar' -OutFile '%~dp0tools\apktool.jar' -UseBasicParsing}"
    if exist "%~dp0tools\apktool.jar" (echo   [OK]) else (echo   [FAIL] Kiem tra ket noi mang)
)

:: ── uber-apk-signer ──
echo [2/3] Downloading uber-apk-signer v2.1.0...
if exist "%~dp0tools\uber-apk-signer.jar" (
    echo   [SKIP] uber-apk-signer.jar da ton tai
) else (
    powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -Uri 'https://github.com/patrickfav/uber-apk-signer/releases/download/v2.1.0/uber-apk-signer-2.1.0.jar' -OutFile '%~dp0tools\uber-apk-signer.jar' -UseBasicParsing}"
    if exist "%~dp0tools\uber-apk-signer.jar" (echo   [OK]) else (echo   [FAIL])
)

:: ── apktool.bat ──
echo [3/3] Creating apktool.bat wrapper...
copy "%~dp0tools\apktool_wrapper.bat" "%~dp0tools\apktool.bat" >nul 2>&1
echo   [OK]

echo.
echo  ================================================
echo   Tools da duoc download vao: %~dp0tools\
echo   Chay setup_check.bat de kiem tra
echo  ================================================
echo.
pause
