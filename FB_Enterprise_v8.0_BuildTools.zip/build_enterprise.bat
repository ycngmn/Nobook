@echo off
setlocal EnableDelayedExpansion
title FB Enterprise AdBlocker v8.0 — Auto Build
color 0A

echo.
echo  ====================================================
echo    FB Enterprise AdBlocker v8.0 ^| ReVanced ARM64
echo    Target: facebook-arm64-v8a-derevanced.apk
echo  ====================================================
echo.

:: ── CONFIG — Thay doi neu can ──
set WORK=%~dp0
set APK_IN=%WORK%input\facebook-arm64-v8a-derevanced.apk
set SRC=%WORK%fb_src_mod
set ENT=%WORK%FB_Enterprise_AdBlocker_v8.0
set OUT=%WORK%output
set KS=%WORK%fb_enterprise.jks
set KS_ALIAS=fb_ent
set KS_PASS=FBEnterprise@2026
set APKTOOL=java -jar "%WORK%tools\apktool.jar"
set SIGNER=java -jar "%WORK%tools\uber-apk-signer.jar"

:: ── Kiểm tra prerequisites ──
echo [PRE-CHECK]
if not exist "%WORK%tools\apktool.jar"         echo MISSING: tools\apktool.jar   && goto :die
if not exist "%WORK%tools\uber-apk-signer.jar" echo MISSING: tools\uber-apk-signer.jar && goto :die
if not exist "%APK_IN%"                        echo MISSING: %APK_IN% && goto :die
if not exist "%ENT%\smali\com\enterprise\mod"  echo MISSING: Enterprise smali dir && goto :die
if not exist "%ENT%\assets\guard_v9.2_Enterprise_FINAL.js" echo MISSING: guard.js && goto :die
echo   [OK] All prerequisites met

:: ══════════════════════════════════════════════════════
:: BƯỚC 1 — DECOMPILE
:: ══════════════════════════════════════════════════════
echo.
echo [1/7] DECOMPILE APK...
if exist "%SRC%\AndroidManifest.xml" (
    echo   [SKIP] fb_src_mod da ton tai. Xoa de build lai:
    echo          rmdir /s /q "%SRC%"
) else (
    %APKTOOL% if "%APK_IN%" 2>nul
    %APKTOOL% d "%APK_IN%" -o "%SRC%" -f --no-res
    if errorlevel 1 (
        echo   [RETRY] Thu lai khong co --no-res...
        %APKTOOL% d "%APK_IN%" -o "%SRC%" -f
        if errorlevel 1 goto :die
    )
    echo   [OK] Decompile xong
)

:: ══════════════════════════════════════════════════════
:: BƯỚC 2 — COPY ENTERPRISE FILES
:: ══════════════════════════════════════════════════════
echo.
echo [2/7] COPY ENTERPRISE MOD FILES...

:: Tạo thư mục Enterprise trong DEX 2
if not exist "%SRC%\smali_classes2" mkdir "%SRC%\smali_classes2"
mkdir "%SRC%\smali_classes2\com\enterprise\mod" 2>nul

:: Copy smali files
set COUNT=0
for %%f in ("%ENT%\smali\com\enterprise\mod\*.smali") do (
    copy "%%f" "%SRC%\smali_classes2\com\enterprise\mod\" >nul
    set /a COUNT+=1
)
echo   [OK] Copied !COUNT! smali files

:: Copy guard.js
if not exist "%SRC%\assets" mkdir "%SRC%\assets"
copy "%ENT%\assets\guard_v9.2_Enterprise_FINAL.js" "%SRC%\assets\" >nul
echo   [OK] guard_v9.2_Enterprise_FINAL.js

:: ══════════════════════════════════════════════════════
:: BƯỚC 3 — PATCH ANDROIDMANIFEST.XML
:: ══════════════════════════════════════════════════════
echo.
echo [3/7] PATCH ANDROIDMANIFEST.XML...

:: Detect Application class hiện tại
for /f "tokens=*" %%l in ('findstr "android:name" "%SRC%\AndroidManifest.xml" ^| findstr "Application"') do (
    set MANIFEST_LINE=%%l
)

:: Thay FacebookApplication → ModApplication
powershell -Command ^
  "(Get-Content '%SRC%\AndroidManifest.xml' -Raw) -replace 'com\.facebook\.katana\.app\.FacebookApplication', 'com.enterprise.mod.ModApplication' | Set-Content '%SRC%\AndroidManifest.xml' -NoNewline"

powershell -Command ^
  "(Get-Content '%SRC%\AndroidManifest.xml' -Raw) -replace 'com\.facebook\.app\.KatanaApplication', 'com.enterprise.mod.ModApplication' | Set-Content '%SRC%\AndroidManifest.xml' -NoNewline"

:: Disable AudienceNetworkService
powershell -Command ^
  "(Get-Content '%SRC%\AndroidManifest.xml' -Raw) -replace '(android:name=""com\.facebook\.audiencenetwork\.AudienceNetworkService"")', '$1 android:enabled=""false""' | Set-Content '%SRC%\AndroidManifest.xml' -NoNewline"

:: Verify
findstr "ModApplication" "%SRC%\AndroidManifest.xml" >nul
if errorlevel 1 (
    echo   [WARN] ModApplication KHONG TIM THAY trong Manifest!
    echo          Kiem tra Application class bang lenh:
    echo          findstr "android:name" "%SRC%\AndroidManifest.xml"
    echo          Sau do them thu cong.
) else (
    echo   [OK] ModApplication patched
)
echo   [OK] Manifest done

:: ══════════════════════════════════════════════════════
:: BƯỚC 4 — PATCH SMALI (Tự động)
:: ══════════════════════════════════════════════════════
echo.
echo [4/7] AUTO-PATCH SMALI METHODS...

:: Tìm FacebookApplicationImpl.smali
set IMPL_FILE=
for /f "delims=" %%f in ('dir /s /b "%SRC%\*FacebookApplicationImpl.smali" 2^>nul') do set IMPL_FILE=%%f

if defined IMPL_FILE (
    echo   Found: !IMPL_FILE!
    :: Kiểm tra đã inject chưa
    findstr "ModInit" "!IMPL_FILE!" >nul
    if errorlevel 1 (
        echo   [WARN] ModInit CHUA INJECT vao FacebookApplicationImpl
        echo          >>> Mo file bang VSCode va inject thu cong:
        echo          code "!IMPL_FILE!"
        echo          Xem: PATCH_GUIDE_PER_FILE_v8.md Section PATCH 1
    ) else (
        echo   [OK] ModInit da duoc inject
    )
) else (
    echo   [WARN] FacebookApplicationImpl.smali KHONG TIM THAY
)

:: Kiểm tra QuickPromotionDefinition
set QP_FILE=
for /f "delims=" %%f in ('dir /s /b "%SRC%\smali_classes2\*QuickPromotionDefinition.smali" 2^>nul') do set QP_FILE=%%f

if defined QP_FILE (
    echo   Found QP: !QP_FILE!
    echo   [INFO] Kiem tra tay: code "!QP_FILE!"
) else (
    echo   [WARN] QuickPromotionDefinition.smali not found
)

echo   [NOTE] 7 critical smali patches can lam thu cong
echo          Xem chi tiet: PATCH_GUIDE_PER_FILE_v8.md

:: ══════════════════════════════════════════════════════
:: BƯỚC 5 — KEYSTORE
:: ══════════════════════════════════════════════════════
echo.
echo [5/7] KEYSTORE...
if exist "%KS%" (
    echo   [SKIP] Keystore da ton tai: %KS%
) else (
    echo   Tao keystore moi...
    keytool -genkey -v ^
      -keystore "%KS%" ^
      -alias %KS_ALIAS% ^
      -keyalg RSA ^
      -keysize 2048 ^
      -validity 10000 ^
      -storepass %KS_PASS% ^
      -keypass %KS_PASS% ^
      -dname "CN=FBEnterprise, OU=Mod, O=Enterprise, L=Hanoi, ST=HN, C=VN" >nul 2>&1
    if exist "%KS%" (echo   [OK] Keystore created) else (echo   [FAIL] Keytool error && goto :die)
)

:: ══════════════════════════════════════════════════════
:: BƯỚC 6 — BUILD APK
:: ══════════════════════════════════════════════════════
echo.
echo [6/7] BUILD APK (10-15 phut)...
echo   ...

if not exist "%OUT%" mkdir "%OUT%"

%APKTOOL% b "%SRC%" -o "%WORK%fb_ent_unsigned.apk" --use-aapt2
if errorlevel 1 (
    echo   [RETRY] Khong co --use-aapt2...
    %APKTOOL% b "%SRC%" -o "%WORK%fb_ent_unsigned.apk"
    if errorlevel 1 goto :die
)
echo   [OK] Build thanh cong

:: ══════════════════════════════════════════════════════
:: BƯỚC 7 — SIGN + ZIPALIGN
:: ══════════════════════════════════════════════════════
echo.
echo [7/7] SIGN APK...
%SIGNER% ^
  --apks "%WORK%fb_ent_unsigned.apk" ^
  --ks "%KS%" ^
  --ksAlias %KS_ALIAS% ^
  --ksPass %KS_PASS% ^
  --ksKeyPass %KS_PASS% ^
  --out "%OUT%"
if errorlevel 1 goto :die

:: Đổi tên
for %%f in ("%OUT%\*aligned-signed.apk") do (
    ren "%%f" "FB_Enterprise_v8.0_ReVanced_arm64.apk" 2>nul
)

echo.
echo  ====================================================
echo    BUILD THANH CONG!
echo.
for %%f in ("%OUT%\FB_Enterprise_v8.0_ReVanced_arm64.apk") do (
    echo    Output : %%f
    echo    Size   : %%~zf bytes
)
echo.
echo    Cai len dien thoai:
echo    adb install "%OUT%\FB_Enterprise_v8.0_ReVanced_arm64.apk"
echo  ====================================================
echo.
goto :end

:die
echo.
echo  [BUILD FAILED] Xem loi o tren.
echo  Loi pho bien:
echo    1. Java chua cai  → installeren JDK 17
echo    2. APK khong co   → copy vao input\
echo    3. Smali loi      → kiem tra PATCH_GUIDE
pause
exit /b 1

:end
endlocal
pause
