#!/usr/bin/env python3
# patch_smali_auto.py — Tự động patch các smali methods
# Dùng: python patch_smali_auto.py C:\fbwork\fb_src_mod
# 20/04/2026 — FB Enterprise AdBlocker v8.0

import os, sys, re

SRC = sys.argv[1] if len(sys.argv) > 1 else r"C:\fbwork\fb_src_mod"

PATCHES = {
    # QuickPromotion boolean kills
    "isEligible()Z": """.method public final isEligible()Z
    .registers 2
    const/4 v0, 0x0
    return v0
.end method""",

    "shouldDisplay()Z": """.method public final shouldDisplay()Z
    .registers 2
    const/4 v0, 0x0
    return v0
.end method""",

    "isValid()Z": """.method public final isValid()Z
    .registers 2
    const/4 v0, 0x0
    return v0
.end method""",

    "shouldShowTab()Z": """.method public shouldShowTab()Z
    .registers 2
    const/4 v0, 0x0
    return v0
.end method""",

    "isAdUnit()Z": """.method public isAdUnit()Z
    .registers 2
    const/4 v0, 0x0
    return v0
.end method""",

    "isSponsored()Z": """.method public isSponsored()Z
    .registers 2
    const/4 v0, 0x0
    return v0
.end method""",

    "isVideoAdUnit()Z": """.method public isVideoAdUnit()Z
    .registers 2
    const/4 v0, 0x0
    return v0
.end method""",

    "isReelAdUnit()Z": """.method public isReelAdUnit()Z
    .registers 2
    const/4 v0, 0x0
    return v0
.end method""",

    "isMarketplaceAd()Z": """.method public isMarketplaceAd()Z
    .registers 2
    const/4 v0, 0x0
    return v0
.end method""",
}

# Targets cần kill service
SERVICE_KILLS = {
    "AudienceNetworkRemoteService.smali": ["onStartCommand", "onCreate", "onBind"],
    "AudienceNetworkService.smali": ["onCreate", "onStartCommand"],
    "AudienceNetworkRemoteAPIsSetup.smali": ["setup", "initialize"],
}

# Activity targets cần finish()
FINISH_ACTIVITIES = [
    "QuickPromotionInterstitialActivity.smali",
    "QuickPromotionLoginInterstitialBloksActivity.smali",
    "QuickPromotionLoginInterstitialBloksActivityV2.smali",
    "QuickPromotionFbInterstitialActivity.smali",
    "QuickPromotionFbLoginInterstitialActivity.smali",
]

patched_count = 0
skipped_count = 0

def patch_method_body(content, method_sig, new_body):
    """Thay toàn bộ body của method."""
    pattern = rf'(\.method [^\n]*{re.escape(method_sig)}[^\n]*\n).*?(\.end method)'
    replacement = r'\1' + new_body.split('\n    ', 1)[-1] if '    ' in new_body else new_body
    return content, False  # placeholder

def process_file(filepath, filename):
    global patched_count, skipped_count
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
    except:
        return

    modified = False

    # ── Patch boolean methods ──
    for sig, new_code in PATCHES.items():
        method_name = sig.split('(')[0]
        if method_name not in content:
            continue
        # Tìm method block
        pattern = r'(\.method (?:public|protected|private)[^\n]*' + re.escape(method_name) + r'\(\)Z\n)(\s+\.(?:locals|registers).*?\n)(.*?)(\.end method)'
        def replace_method(m):
            header = m.group(1)
            # Chỉ thay nếu chưa có const/4 v0, 0x0
            if 'const/4 v0, 0x0' in m.group(0) and 'return v0' in m.group(0):
                return m.group(0)  # đã patch
            return header + '    .registers 2\n    const/4 v0, 0x0\n    return v0\n' + m.group(4)

        new_content = re.sub(pattern, replace_method, content, flags=re.DOTALL)
        if new_content != content:
            content = new_content
            modified = True

    # ── Kill services ──
    for kill_file, methods in SERVICE_KILLS.items():
        if filename == kill_file:
            for method in methods:
                if method + '(' in content:
                    # return-void for void methods, 0x2 for onStartCommand
                    if method == 'onStartCommand':
                        pattern = r'(\.method public ' + method + r'\(.*?\)I\n).*?(\.end method)'
                        replacement = r'\1    .registers 2\n    const/4 v0, 0x2\n    return v0\n\2'
                    elif 'IBinder' in content and method == 'onBind':
                        pattern = r'(\.method public ' + method + r'\(.*?\).*?\n).*?(\.end method)'
                        replacement = r'\1    .registers 2\n    const/4 v0, 0x0\n    return-object v0\n\2'
                    else:
                        pattern = r'(\.method public ' + method + r'\(.*?\)V\n).*?(\.end method)'
                        replacement = r'\1    .registers 1\n    return-void\n\2'
                    new_content = re.sub(pattern, replacement, content, flags=re.DOTALL)
                    if new_content != content:
                        content = new_content
                        modified = True

    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"  [PATCHED] {filename}")
        patched_count += 1
    else:
        skipped_count += 1

print("=" * 60)
print("  FB Enterprise Auto-Patcher v8.0")
print(f"  Source: {SRC}")
print("=" * 60)

for root, dirs, files in os.walk(SRC):
    for fname in files:
        if fname.endswith('.smali'):
            process_file(os.path.join(root, fname), fname)

print(f"\n  Patched: {patched_count} files")
print(f"  Skipped: {skipped_count} files")
print("\n  [NOTE] Cac patch can lam thu cong (khong tu dong duoc):")
print("    1. FacebookApplicationImpl.smali — inject ModInit.boot()")
print("    2. BrowserLiteFragment.smali — inject guard.js")
print("    3. QuickPromotionDefinition.smali — kiem tra methods ton tai")
print("  Xem: PATCH_GUIDE_PER_FILE_v8.md")
