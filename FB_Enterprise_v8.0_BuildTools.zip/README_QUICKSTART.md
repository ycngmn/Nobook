# FB Enterprise AdBlocker v8.0 — Quick Start Guide

## ⚡ 3 BƯỚC ĐƠN GIẢN NHẤT

### Bước 1 — Tải tools (1 lần duy nhất)
```
Double-click: download_tools.bat
```
→ Tự động tải apktool + uber-apk-signer vào tools\

### Bước 2 — Tải APK Facebook vào input\
```
URL: https://github.com/FiorenMas/Revanced-And-Revanced-Extended-Non-Root/releases/download/all/facebook-arm64-v8a-derevanced.apk
Lưu vào: C:\fbwork\input\facebook-arm64-v8a-derevanced.apk
```

### Bước 3 — Build tự động
```
Double-click: build_enterprise.bat
Đợi 15-20 phút
```
→ Output: `output\FB_Enterprise_v8.0_ReVanced_arm64.apk`

---

## 📋 Kiểm tra môi trường trước khi build

```cmd
setup_check.bat
```

---

## 🔧 Patch thủ công (nếu build_enterprise.bat cần thêm)

```cmd
python patch_smali_auto.py C:\fbwork\fb_src_mod
```

Sau đó patch 3 file còn lại theo: `PATCH_GUIDE_PER_FILE_v8.md`

---

## 📁 Files trong gói này

| File | Mục đích |
|------|----------|
| `download_tools.bat` | Tự động tải apktool + uber-signer |
| `setup_check.bat` | Kiểm tra môi trường |
| `build_enterprise.bat` | Build tự động toàn bộ |
| `patch_smali_auto.py` | Auto-patch smali methods |
| `tools\apktool.bat` | Wrapper cho apktool.jar |
| `links.txt` | Link tải tất cả tools |

---

## ⚠️ Yêu cầu hệ thống

- Windows 10/11 x64
- Java JDK 17+ (xem links.txt)
- RAM: tối thiểu 4GB free
- Disk: tối thiểu 5GB free
- Internet để tải APK + tools

---

*FB Enterprise AdBlocker v8.0 | 20/04/2026*
