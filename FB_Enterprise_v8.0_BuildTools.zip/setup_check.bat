@echo off
title FB Enterprise v8.0 — Setup Checker
color 0A
echo.
echo  ================================================
echo    FB Enterprise AdBlocker v8.0 — Setup Check
echo  ================================================
echo.

set PASS=0
set FAIL=0
set TOOLS=%~dp0tools

:: ── Kiểm tra Java ──
echo [JAVA]
java -version >nul 2>&1
if errorlevel 1 (
    echo   [FAIL] Java CHUA DUOC CAI DAT
    echo          Download: https://adoptium.net/temurin/releases/?version=17
    set /a FAIL+=1
) else (
    for /f "tokens=3" %%v in ('java -version 2^>^&1 ^| findstr /i "version"') do (
        echo   [OK]   Java %%v
    )
    set /a PASS+=1
)

:: ── Kiểm tra apktool ──
echo.
echo [APKTOOL]
if exist "%TOOLS%\apktool.jar" (
    for %%A in ("%TOOLS%\apktool.jar") do echo   [OK]   apktool.jar (%%~zA bytes)
    set /a PASS+=1
) else (
    echo   [FAIL] apktool.jar KHONG TIM THAY
    echo          Download: https://apktool.org/
    set /a FAIL+=1
)

:: ── Kiểm tra uber-apk-signer ──
echo.
echo [UBER-APK-SIGNER]
if exist "%TOOLS%\uber-apk-signer.jar" (
    for %%A in ("%TOOLS%\uber-apk-signer.jar") do echo   [OK]   uber-apk-signer.jar (%%~zA bytes)
    set /a PASS+=1
) else (
    echo   [FAIL] uber-apk-signer.jar KHONG TIM THAY
    echo          Download: https://github.com/patrickfav/uber-apk-signer/releases
    set /a FAIL+=1
)

:: ── Kiểm tra keytool ──
echo.
echo [KEYTOOL]
keytool -help >nul 2>&1
if errorlevel 1 (
    echo   [FAIL] keytool KHONG CO (can Java JDK)
    set /a FAIL+=1
) else (
    echo   [OK]   keytool available
    set /a PASS+=1
)

:: ── Kiểm tra adb ──
echo.
echo [ADB]
adb version >nul 2>&1
if errorlevel 1 (
    echo   [WARN] adb KHONG CO (can cho buoc cai APK qua USB)
    echo          Download: https://developer.android.com/tools/releases/platform-tools
) else (
    for /f "tokens=5" %%v in ('adb version 2^>^&1 ^| findstr "version"') do echo   [OK]   adb %%v
)

:: ── Kiểm tra Enterprise ZIP ──
echo.
echo [ENTERPRISE MOD FILES]
if exist "%~dp0FB_Enterprise_AdBlocker_v8.0\smali\com\enterprise\mod\ModInit.smali" (
    set /a COUNT=0
    for %%f in ("%~dp0FB_Enterprise_AdBlocker_v8.0\smali\com\enterprise\mod\*.smali") do set /a COUNT+=1
    echo   [OK]   Enterprise smali files found
    set /a PASS+=1
) else (
    echo   [FAIL] FB_Enterprise_AdBlocker_v8.0 chua giai nen hoac thieu files
    set /a FAIL+=1
)

if exist "%~dp0FB_Enterprise_AdBlocker_v8.0\assets\guard_v9.2_Enterprise_FINAL.js" (
    echo   [OK]   guard_v9.2_Enterprise_FINAL.js
) else (
    echo   [FAIL] guard_v9.2_Enterprise_FINAL.js MISSING
)

:: ── Kiểm tra input APK ──
echo.
echo [INPUT APK]
if exist "%~dp0input\facebook-arm64-v8a-derevanced.apk" (
    for %%A in ("%~dp0input\facebook-arm64-v8a-derevanced.apk") do echo   [OK]   APK (%%~zA bytes)
    set /a PASS+=1
) else (
    echo   [FAIL] facebook-arm64-v8a-derevanced.apk KHONG TIM THAY trong input\
    echo          Download tu: https://github.com/FiorenMas/Revanced-And-Revanced-Extended-Non-Root
    set /a FAIL+=1
)

:: ── Tổng kết ──
echo.
echo  ================================================
echo   PASS: %PASS% / FAIL: %FAIL%
if %FAIL% EQU 0 (
    echo   STATUS: SAN SANG BUILD!
    echo          Chay: build_enterprise.bat
) else (
    echo   STATUS: CAN SUA %FAIL% LOI TRUOC KHI BUILD
)
echo  ================================================
echo.
pause
